
HM_Array1 = [
[150],
["Experts","http://www.webreference.com/experts/",1,0,1],
["Contents","http://www.webreference.com/index2.html",1,0,0],
["Services","http://www.webreference.com/index2.html",1,0,1],
["About","http://www.webreference.com/about.html",1,0,0]
]

HM_Array1_1 = [
[],
["3-D Animation","http://www.webreference.com/3d/",1,0,0],
["Design","http://www.webreference.com/dlab/",1,0,0],
["HTML","http://www.webreference.com/html/",1,0,0],
["JavaScript","http://www.webreference.com/js/",1,0,0],
["Graphics","http://www.webreference.com/graphics/",1,0,0],
["DHTML","http://www.webreference.com/dhtml/",1,0,1],
["Perl","http://www.webreference.com/perl/",1,0,0],
["XML","http://www.webreference.com/xml/",1,0,0]
]

HM_Array1_3 = [
[],
["Features","http://www.webreference.com/articles.html",1,0,0],
["Forum","http://www.webreference.com/cgi-bin/Ultimate.cgi?action=intro",1,0,0],
["How-to","http://www.webreference.com/dev/",1,0,0],
["New","http://www.webreference.com/headlines/",1,0,0],
["Hot Sites","http://www.webreference.com/hot/",1,0,0]
]

HM_Array1_1_6 = [
[]
["Diner","http://www.webreference.com/dhtml/diner/",1,0,0],
["Dynomat","http://www.webreference.com/dhtml/dynomat/",1,0,0],
["Links","http://www.webreference.com/dhtml/links/",1,0,0]
]

HM_Array2 = [
[100,		// menu width
200,		// left_position
50,			// top_position
"red",      // font_color
"yellow",   // mouseover_font_color
"yellow",   // background_color
"black",    // mouseover_background_color
"blue",     // border_color
"green",    // separator_color
1,			// top_is_permanent
1,          // top_is_horizontal
0,          // tree_is_horizontal
1,          // position_under
0,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["Experts","http://www.webreference.com/experts/",1,0,1],
["Contents","http://www.webreference.com/index2.html",1,0,0],
["Services","http://www.webreference.com/index2.html",1,0,1],
["About","http://www.webreference.com/about.html",1,0,0]
]

HM_Array2_1 = [
[],
["3-D Animation","http://www.webreference.com/3d/",1,0,0],
["Design","http://www.webreference.com/dlab/",1,0,0],
["HTML","http://www.webreference.com/html/",1,0,0],
["JavaScript","http://www.webreference.com/js/",1,0,0],
["Graphics","http://www.webreference.com/graphics/",1,0,0],
["DHTML","http://www.webreference.com/dhtml/",1,0,1],
["Perl","http://www.webreference.com/perl/",1,0,0],
["XML","http://www.webreference.com/xml/",1,0,0]
]

HM_Array2_3 = [
[],
["Features","http://www.webreference.com/articles.html",1,0,0],
["Forum","http://www.webreference.com/cgi-bin/Ultimate.cgi?action=intro",1,0,0],
["How-to","http://www.webreference.com/dev/",1,0,0],
["New","http://www.webreference.com/headlines/",1,0,0],
["Hot Sites","http://www.webreference.com/hot/",1,0,0]
]

HM_Array2_1_6 = [
[],
["Diner","http://www.webreference.com/dhtml/diner/",1,0,0],
["Dynomat","http://www.webreference.com/dhtml/dynomat/",1,0,0],
["Links","http://www.webreference.com/dhtml/links/",1,0,0]
]

HM_Array3 = [
[120,		// menu width
200,		// left_position
200,			// top_position
"black",      // font_color
"white",   // mouseover_font_color
"white",   // background_color
"black",    // mouseover_background_color
"black",     // border_color
"gray",    // separator_color
0,			// top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
1,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["Experts","http://www.webreference.com/experts/",1,0,1],
["Contents","http://www.webreference.com/index2.html",1,0,0],
["Services","http://www.webreference.com/index2.html",1,0,1],
["About","http://www.webreference.com/about.html",1,0,0]
]

HM_Array3_1 = [
[],
["3-D Animation","http://www.webreference.com/3d/",1,0,0],
["Design","http://www.webreference.com/dlab/",1,0,0],
["HTML","http://www.webreference.com/html/",1,0,0],
["JavaScript","http://www.webreference.com/js/",1,0,0],
["Graphics","http://www.webreference.com/graphics/",1,0,0],
["DHTML","http://www.webreference.com/dhtml/",1,0,1],
["Perl","http://www.webreference.com/perl/",1,0,0],
["XML","http://www.webreference.com/xml/",1,0,0]
]

HM_Array3_3 = [
[],
["Features","http://www.webreference.com/articles.html",1,0,0],
["Forum","http://www.webreference.com/cgi-bin/Ultimate.cgi?action=intro",1,0,0],
["How-to","http://www.webreference.com/dev/",1,0,0],
["New","http://www.webreference.com/headlines/",1,0,0],
["Hot Sites","http://www.webreference.com/hot/",1,0,0]
]

HM_Array3_1_6 = [
[],
["Diner","http://www.webreference.com/dhtml/diner/",1,0,0],
["Dynomat","http://www.webreference.com/dhtml/dynomat/",1,0,0],
["Links","http://www.webreference.com/dhtml/links/",1,0,0]
]

